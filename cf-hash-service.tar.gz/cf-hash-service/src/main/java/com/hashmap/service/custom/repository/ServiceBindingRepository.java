package com.hashmap.service.custom.repository; 

import com.hashmap.service.custom.model.ServiceBinding; 
import org.springframework.data.repository.CrudRepository;

public interface ServiceBindingRepository extends CrudRepository<ServiceBinding,String> {
}
