package com.hashmap.service.custom.repository; 

import com.hashmap.service.custom.model.Service;
import org.springframework.data.repository.CrudRepository;

public interface ServiceRepository extends CrudRepository<Service, String> {
}
